#!/bin/bash
echo "Installing Python via Anaconda..."
chmod +x ./Miniconda3-latest-Linux-x86.sh
./Miniconda3-latest-Linux-x86 -b
echo "Install Pygame and coda-kids"
/home/$USER/miniconda3/bin/pip install coda-kids
echo "Install Pylint"
/home/$USER/miniconda3/bin/pip install pylint
echo "Install Pyinstaller"
/home/$USER/miniconda3/bin/pip install pyinstaller
echo "Installing Visual Studio Code"
sudo dpkg -i ./code_1.12.2-1494423350_i386.deb
sudo apt-get install -f
#sudo add-apt-repository ppa:ubuntu-desktop/ubuntu-make
#sudo apt-get update && sudo apt-get install ubuntu-make
#umake web visual-studio-code
